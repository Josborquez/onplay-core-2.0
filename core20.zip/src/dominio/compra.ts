// Reglas puras de compras — docs/11-SDD-etapa6-compras.md §6.
// Aquí se calcula y se cuadra; leer el PDF y escribir en la base viven en src/api/compras.

export type LectorFactura = 'manual' | 'andina' | 'nico' | 'nico_factura' | 'coqui' | 'devir' | 'asmodee';
export type Moneda = 'CLP' | 'USD';
export type TipoDocumentoCompra = 'factura' | 'boleta' | 'guia' | 'otro';

/** Una línea tal como la entrega un lector (o la digita una persona). Montos en CLP enteros. */
export interface LineaLeida {
  codigoProveedor: string | null;
  descripcion: string;
  bultos: number; // cajas
  unidadesPorBulto: number; // 12 si la caja trae 12
  sueltas: number; // unidades fuera de caja
  neto: number;
  impuestos: number; // IVA + específicos de la línea
  total: number; // neto + impuestos
  /** Monto de la línea en la moneda del documento cuando no es CLP (con decimales); informativo. */
  totalOriginal?: number | null;
}

export interface LineaCalculada extends LineaLeida {
  cantidad: number; // unidades que entran al stock
  costoUnitario: number; // total / cantidad, redondeado
}

export interface TotalesLeidos {
  neto: number;
  impuestos: number;
  total: number;
}

/** Lo que devuelve un lector: cabecera + líneas + lo que no pudo entender (para la persona). */
export interface DocumentoLeido {
  lector: LectorFactura;
  /** Moneda de los montos del documento. Si no es CLP, las líneas traen `totalOriginal` y los CLP se calculan con el tipo de cambio (§6.6). */
  moneda: Moneda;
  proveedor: { rut: string | null; nombre: string | null };
  tipoDocumento: TipoDocumentoCompra;
  numeroDocumento: string | null;
  fechaDocumento: string | null; // ISO yyyy-mm-dd
  lineas: LineaLeida[];
  totales: TotalesLeidos | null;
  /** Total del documento en su moneda cuando no es CLP. */
  totalOriginal?: number | null;
  advertencias: string[];
}

export type ErrorCompra =
  | { codigo: 'CANTIDAD_INVALIDA'; detalle: string }
  | { codigo: 'BULTO_INVALIDO'; detalle: string }
  | { codigo: 'MONTO_INVALIDO'; detalle: string };

/** Proveedores reconocidos por RUT (normalizado, sin puntos) → lector que entiende su documento. */
export const LECTOR_POR_RUT: Readonly<Record<string, LectorFactura>> = {
  '91144000-8': 'andina', // Embotelladora Andina S.A. (Coca-Cola)
  '10879175-6': 'nico_factura', // Distribuidora Nico (Oscar Fernando Leiva Sanhueza): factura; su pedido web usa `nico`
  '76632420-7': 'devir', // Devir Chile Limitada
  '76353094-9': 'asmodee', // Asmodee Chile (Importadora y Comercializadora Skyship SPA)
};

export function lectorPorRut(rutNormalizado: string | null | undefined): LectorFactura | null {
  if (!rutNormalizado) return null;
  return LECTOR_POR_RUT[rutNormalizado] ?? null;
}

/** "14.956" → 14956 · "6,50" → 6.5 · "1.337" → 1337. Formato chileno: punto de miles, coma decimal. */
export function parsearNumeroCl(texto: string): number | null {
  const limpio = texto.trim().replace(/\s/g, '');
  if (!/^-?\d{1,3}(\.\d{3})*(,\d+)?$|^-?\d+(,\d+)?$/.test(limpio)) return null;
  const n = Number(limpio.replace(/\./g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : null;
}

/**
 * «Vital C/G PT600cc x 12 ter» → 12 · «Monster Energy LT473cc x 6» → 6 · «Alfajor Premium x12u» → 12 ·
 * «Lata Pepsi Zero x 6 u» → 6 · «Alfajor Game Blanco x24» → 24 · «45g x5» → 5 · sin «x N» → null.
 * Acepta el sufijo de unidad pegado o separado (u, un, und, unid, unidades).
 */
export function unidadesPorBultoDesdeDescripcion(descripcion: string): number | null {
  const m =
    /(?:^|\s)x\s*(\d{1,3})\s*(?:u|un|und|unid|unidades)?(?=\s|$|[.,;)])/i.exec(descripcion) ??
    /display\s*(\d{1,3})\s*(?:ud|u|un|und|unid|unidades)?\b/i.exec(descripcion); // Devir: «(Display 30ud)»
  if (!m) return null;
  const n = Number(m[1]);
  return n >= 1 ? n : null;
}

/**
 * Cantidad y costo unitario de una línea (§6.1):
 * cantidad = bultos × unidadesPorBulto + sueltas (> 0); costoUnitario = total / cantidad redondeado.
 * El costo unitario es lo que cuesta cada unidad puesta en la tienda: incluye IVA e impuestos
 * específicos (D-E6-1).
 */
export function calcularLinea(l: LineaLeida): LineaCalculada | ErrorCompra {
  if (!Number.isInteger(l.unidadesPorBulto) || l.unidadesPorBulto < 1) {
    return { codigo: 'BULTO_INVALIDO', detalle: 'Las unidades por bulto deben ser un entero ≥ 1.' };
  }
  if (!Number.isInteger(l.bultos) || l.bultos < 0 || !Number.isInteger(l.sueltas) || l.sueltas < 0) {
    return { codigo: 'CANTIDAD_INVALIDA', detalle: 'Bultos y sueltas deben ser enteros ≥ 0.' };
  }
  const cantidad = l.bultos * l.unidadesPorBulto + l.sueltas;
  if (cantidad <= 0) return { codigo: 'CANTIDAD_INVALIDA', detalle: 'La línea debe traer al menos 1 unidad.' };
  const montos: [string, number][] = [
    ['neto', l.neto],
    ['impuestos', l.impuestos],
    ['total', l.total],
  ];
  for (const [nombre, v] of montos) {
    if (!Number.isInteger(v) || v < 0) return { codigo: 'MONTO_INVALIDO', detalle: `El ${nombre} debe ser un entero ≥ 0.` };
  }
  return { ...l, cantidad, costoUnitario: Math.round(l.total / cantidad) };
}

export interface TotalesCuadrados extends TotalesLeidos {
  /** Lo que suman las líneas, para mostrar junto a lo que dice el documento. */
  sumaLineas: TotalesLeidos;
  advertencias: string[];
}

/**
 * Cuadra la suma de las líneas contra los totales del documento (§6.2). Manda el documento (es lo
 * que se paga); si difiere de la suma en más de $1 por línea (redondeos) se avisa, no se bloquea.
 * Sin totales en el documento (digitado a mano), los totales SON la suma.
 */
export function cuadrarTotales(lineas: LineaCalculada[], documento: TotalesLeidos | null): TotalesCuadrados {
  const suma = lineas.reduce(
    (acc, l) => ({ neto: acc.neto + l.neto, impuestos: acc.impuestos + l.impuestos, total: acc.total + l.total }),
    { neto: 0, impuestos: 0, total: 0 },
  );
  if (!documento) return { ...suma, sumaLineas: suma, advertencias: [] };
  const tolerancia = Math.max(1, lineas.length);
  const advertencias: string[] = [];
  for (const campo of ['neto', 'total'] as const) {
    const dif = Math.abs(documento[campo] - suma[campo]);
    if (dif > tolerancia) {
      advertencias.push(
        `El ${campo} del documento ($${documento[campo].toLocaleString('es-CL')}) no cuadra con la suma de las líneas ($${suma[campo].toLocaleString('es-CL')}): diferencia $${dif.toLocaleString('es-CL')}.`,
      );
    }
  }
  return { ...documento, sumaLineas: suma, advertencias };
}

/** "1,398.90" → 1398.9 · ".00" → 0 · "34.80" → 34.8. Formato de EE. UU.: coma de miles, punto decimal. */
export function parsearNumeroUs(texto: string): number | null {
  const limpio = texto.trim().replace(/[\s$]/g, '');
  if (!/^-?(\d{1,3}(,\d{3})*|\d*)(\.\d+)?$/.test(limpio) || limpio === '' || limpio === '-') return null;
  const n = Number(limpio.replace(/,/g, ''));
  return Number.isFinite(n) ? n : null;
}

/**
 * Documento en moneda extranjera (§6.6): pasa cada línea a CLP con el tipo de cambio y reparte los
 * costos de importación en CLP (`costoExtra`: arancel, agente, courier, gastos sin documento) y el
 * IVA recuperable (`ivaExtra`: IVA de importación + IVA de los servicios, §6.7) según el monto
 * original de cada línea, con el resto en la última línea con monto, para que
 * Σ neto = round(totalOriginal × tc) + costoExtra y Σ impuestos = ivaExtra.
 * Sin IVA (solo tipo de cambio): neto = total, impuestos = 0.
 */
export function convertirLineasAClp(lineas: LineaLeida[], tipoCambio: number, costoExtra: number, ivaExtra = 0): LineaLeida[] {
  const base = lineas.map((l) => l.totalOriginal ?? 0);
  const sumaBase = base.reduce((a, b) => a + b, 0);
  const costo = Math.max(0, Math.round(costoExtra));
  const iva = Math.max(0, Math.round(ivaExtra));
  let asignadoCosto = 0;
  let asignadoIva = 0;
  let ultimaConMonto = -1;
  base.forEach((b, i) => {
    if (b > 0) ultimaConMonto = i;
  });
  return lineas.map((l, i) => {
    const enClp = Math.round((l.totalOriginal ?? 0) * tipoCambio);
    let parteCosto = sumaBase > 0 ? Math.round((costo * base[i]!) / sumaBase) : 0;
    let parteIva = sumaBase > 0 ? Math.round((iva * base[i]!) / sumaBase) : 0;
    if (i === ultimaConMonto) {
      parteCosto = costo - asignadoCosto;
      parteIva = iva - asignadoIva;
    }
    asignadoCosto += parteCosto;
    asignadoIva += parteIva;
    const neto = enClp + parteCosto;
    return { ...l, neto, impuestos: parteIva, total: neto + parteIva };
  });
}

/* ---------- C12b · Importación (§6.7, docs/13) ---------- */

/** Lo que dice la DIN (o lo que digita la persona) para calcular los impuestos de importación. */
export interface EntradaImportacion {
  fob: number; // moneda del documento
  flete: number;
  /** Seguro real; null o ausente → presunto 2 % del FOB (Aduana, Res. 1.300/2006). */
  seguro?: number | null;
  /** Ad valorem en %; null → 6 (regla general). 0 con certificado de origen. */
  arancelPct?: number | null;
  /** Dólar aduanero (CLP por unidad) con el que Aduana gira los impuestos. */
  tipoCambioAduana: number;
}

export interface Importacion {
  fob: number;
  flete: number;
  seguro: number;
  seguroPresunto: boolean;
  cif: number;
  arancelPct: number;
  arancelOriginal: number; // en la moneda del documento
  ivaOriginal: number;
  totalGiroOriginal: number;
  arancel: number; // CLP: costo
  ivaImportacion: number; // CLP: crédito fiscal
  totalGiro: number; // CLP: lo que se paga a Tesorería
}

const centavos = (n: number) => Math.round(n * 100) / 100;

/**
 * CIF = FOB + flete + seguro; ad valorem = % del CIF; IVA = 19 % de (CIF + ad valorem) (docs/13 §1).
 * Confirmado con la DIN 1150127395-5: FOB 4.735,16 + 318,80 + 94,70 → CIF 5.148,66, 308,93 y 1.036,93.
 */
export function calcularImportacion(e: EntradaImportacion): Importacion {
  const fob = Math.max(0, e.fob);
  const flete = Math.max(0, e.flete);
  // Presunto si no viene o si es exactamente el 2 % del FOB (así lo pone la DIN cuando no hay póliza).
  const seguroPresunto = e.seguro === null || e.seguro === undefined || Math.abs(e.seguro - centavos(fob * 0.02)) < 0.011;
  const seguro = e.seguro === null || e.seguro === undefined ? centavos(fob * 0.02) : Math.max(0, e.seguro);
  const arancelPct = e.arancelPct === null || e.arancelPct === undefined ? 6 : Math.max(0, e.arancelPct);
  const cif = centavos(fob + flete + seguro);
  const arancelOriginal = centavos((cif * arancelPct) / 100);
  const ivaOriginal = centavos((cif + arancelOriginal) * 0.19);
  const totalGiroOriginal = centavos(arancelOriginal + ivaOriginal);
  const tc = Math.max(0, e.tipoCambioAduana);
  return {
    fob,
    flete,
    seguro,
    seguroPresunto,
    cif,
    arancelPct,
    arancelOriginal,
    ivaOriginal,
    totalGiroOriginal,
    arancel: Math.round(arancelOriginal * tc),
    ivaImportacion: Math.round(ivaOriginal * tc),
    totalGiro: Math.round(totalGiroOriginal * tc),
  };
}

export interface GastoImportacion {
  montoNeto: number; // CLP: costo
  iva: number; // CLP: crédito fiscal
}

export interface ResumenImportacion {
  /** Σ neto de las líneas: mercancía + flete + arancel + gastos netos. Lo que cuesta lo que llegó. */
  costoPuesto: number;
  /** Σ impuestos de las líneas: IVA de importación + IVA de los servicios. Vuelve en el F29. */
  ivaRecuperable: number;
  /** costoPuesto + ivaRecuperable: lo que salió de la caja. */
  desembolso: number;
  fobClp: number | null;
  /** (costoPuesto / fobClp − 1) × 100, una cifra: cuánto encarece la importación al precio de lista. */
  sobreFobPct: number | null;
  gastosNetos: number;
  ivaGastos: number;
  /** Σ totalOriginal de las líneas contra FOB + flete de la DIN: si difiere > 1 %, algo no cuadra. */
  cuadre: { lineas: number; din: number; difiere: boolean } | null;
}

/** Cifras de la tarjeta «Importación» a partir de las líneas ya repartidas (docs/13 §5). */
export function resumenImportacion(
  lineas: { neto: number; impuestos: number; total: number; totalOriginal?: number | null }[],
  compra: { tipoCambio: number | null; fob: number | null; flete: number | null },
  gastos: GastoImportacion[],
): ResumenImportacion {
  const costoPuesto = lineas.reduce((a, l) => a + l.neto, 0);
  const ivaRecuperable = lineas.reduce((a, l) => a + l.impuestos, 0);
  const fobClp = compra.fob != null && compra.tipoCambio ? Math.round(compra.fob * compra.tipoCambio) : null;
  const sumaOriginal = centavos(lineas.reduce((a, l) => a + (l.totalOriginal ?? 0), 0));
  const din = compra.fob != null ? centavos(compra.fob + (compra.flete ?? 0)) : null;
  return {
    costoPuesto,
    ivaRecuperable,
    desembolso: costoPuesto + ivaRecuperable,
    fobClp,
    sobreFobPct: fobClp ? Math.round((costoPuesto / fobClp - 1) * 1000) / 10 : null,
    gastosNetos: gastos.reduce((a, g) => a + g.montoNeto, 0),
    ivaGastos: gastos.reduce((a, g) => a + g.iva, 0),
    cuadre: din !== null ? { lineas: sumaOriginal, din, difiere: din > 0 && Math.abs(sumaOriginal - din) / din > 0.01 } : null,
  };
}

/** Margen sobre el precio de venta, en %: (venta − costo) / venta. Null si no hay precio. */
export function margenPorcentaje(precioVenta: number, costoUnitario: number): number | null {
  if (!(precioVenta > 0)) return null;
  return Math.round(((precioVenta - costoUnitario) / precioVenta) * 1000) / 10;
}

/** Precio de venta que deja el margen pedido (en %), redondeado hacia arriba al múltiplo indicado (CLP). */
export function precioParaMargen(costoUnitario: number, margenPct: number, multiplo = 10): number {
  if (!(margenPct < 100)) return 0;
  const bruto = costoUnitario / (1 - margenPct / 100);
  return Math.ceil(bruto / multiplo) * multiplo;
}

/** "09-09-2026" | "09/09/2026" | "1/9/2026" → "2026-09-09"; "2026-09-09" tal cual; otra cosa → null. */
export function fechaIsoDesdeCl(texto: string): string | null {
  const t = texto.trim();
  let m = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/.exec(t);
  if (m) return `${m[3]}-${m[2]!.padStart(2, '0')}-${m[1]!.padStart(2, '0')}`;
  m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t);
  if (m) return t;
  return null;
}
